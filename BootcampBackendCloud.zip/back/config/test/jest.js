module.exports = {
    rootDir: '../../',
    preset: 'ts-jest',
    restoreMocks: true,
  };
  