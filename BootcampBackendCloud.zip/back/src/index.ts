import { config } from 'dotenv';
config();

require('./app');
